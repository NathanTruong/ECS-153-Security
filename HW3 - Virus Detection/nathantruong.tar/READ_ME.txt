Nathan Truong
SID: 998163923

For this program I have the features required working to my knowledge and tests.
The program works as the following-

- If  you run the programn only then it will default to vdetect.str and take user inputs where ctrl+d is press to comapre the strings
- -s, -q, -d will all work and do as they are supposed

My programs uses one unordered_map to store the names and signatures as well as multiple vectors to store the files
The hex parsing is done rather brute force and changes in a manual fashion.

Comments before the function details what the function does and what the passed variables do.
I only commented lines and areas of the code I felt were necessary or unclear to the reader.

I have used refrence from cplusplues.com for various things such as how to print a vector or how to use getc.
